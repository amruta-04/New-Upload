﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Defect_Tracker_Tool.Entities
{
    public class DefectResponseEntity
    {
        public int DEFECT_ID { get; set; }
        public string DEFECT_NAME { get; set; }
        public string DESCRIPTION { get; set; }
        public string CREATED_BY_USER { get; set; }
        public string DEDUCTED_DATE { get; set; }
        public string PRIORITY { get; set; }
        public string SCREEN { get; set; }
        public string ASSIGNED_TO_ID { get; set; }
        public string ASSIGNED_TO_NAME { get; set; }
        public string COMPLETED_DATE { get; set; }
        public string STATUS { get; set; }
        public string COMMENTS { get; set; }
    }
}