﻿using ClosedXML.Excel;
using Defect_Tracker_Tool.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Defect_Tracker_Tool.Controllers
{
    [Authorize]
    public class DefectsController : ApiController
    {
        #region Get All Defects

        
        [HttpGet]
        [Route("api/Defects/GetAllDefects")]
        public IEnumerable<DEFECT> GetAllDefects()
        {
            //IEnumerable<DefectResponseEntity> def = new List<DefectResponseEntity>();
            DefectResponseEntity request = new DefectResponseEntity();
            //
            using (DefectsDBEntities entities = new DefectsDBEntities())
            {
                IEnumerable<DEFECT> defect = entities.DEFECTS.ToList();
                foreach (var i in defect)
                {
                    //i.DEDUCTED_DATE = DateTime.ParseExact(i.DEDUCTED_DATE.ToString("MM/dd/yyyy", DateTimeFormatInfo.InvariantInfo), "MM/dd/yyyy", CultureInfo.InvariantCulture);
                    i.DEDUCTED_DATE2 = i.DEDUCTED_DATE.ToString("dd/MM/yyyy");
                    i.COMPLETED_DATE2 = i.COMPLETED_DATE?.ToString("dd/MM/yyyy");
                };
                return defect;

            }
        }
        #endregion

        #region Search Defect By ID

        
        [HttpGet]
        [Route("api/Defects/SearchDefectById")]
        public IEnumerable<DEFECT> SearchDefectById(int? id)
        {
            
            using (DefectsDBEntities entities = new DefectsDBEntities())
            {
                if (id != null)
                {
                    IEnumerable<DEFECT> def = entities.DEFECTS.Where(a => a.DEFECT_ID == id).ToList();
                    foreach (var i in def)
                    {
                        //i.DEDUCTED_DATE = DateTime.ParseExact(i.DEDUCTED_DATE.ToString("MM/dd/yyyy", DateTimeFormatInfo.InvariantInfo), "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        i.DEDUCTED_DATE2 = i.DEDUCTED_DATE.ToString("yyyy-MM-dd");
                        i.COMPLETED_DATE2 = i.COMPLETED_DATE?.ToString("yyyy-MM-dd");
                    };
                    return def;
                }
                else
                {
                    IEnumerable<DEFECT> def = entities.DEFECTS.ToList();
                    return def;
                }
                
            }
        }
        #endregion

        #region Search Defects By Date

        
        [HttpGet]
        [Route("api/Defects/SearchDefectsByDate")]
        public IEnumerable<DEFECT> SearchDefectsByDate(DateTime? date1, DateTime? date2)
        {

            using (DefectsDBEntities entities = new DefectsDBEntities())
            {
                if (date1 != null && date2 != null)
                {
                    IEnumerable<DEFECT> defect = entities.DEFECTS.Where(a => a.DEDUCTED_DATE >= date1 && a.DEDUCTED_DATE <= date2).ToList();
                    foreach (var i in defect)
                    {
                        //i.DEDUCTED_DATE = DateTime.ParseExact(i.DEDUCTED_DATE.ToString("MM/dd/yyyy", DateTimeFormatInfo.InvariantInfo), "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        i.DEDUCTED_DATE2 = i.DEDUCTED_DATE.ToString("yyyy-MM-dd");
                        i.COMPLETED_DATE2 = i.COMPLETED_DATE?.ToString("yyyy-MM-dd");
                    };
                    return defect;
                }
                else
                {
                    IEnumerable<DEFECT> defect = entities.DEFECTS.ToList();
                    foreach (var i in defect)
                    {
                        //i.DEDUCTED_DATE = DateTime.ParseExact(i.DEDUCTED_DATE.ToString("MM/dd/yyyy", DateTimeFormatInfo.InvariantInfo), "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        i.DEDUCTED_DATE2 = i.DEDUCTED_DATE.ToString("yyyy-MM-dd");
                        i.COMPLETED_DATE2 = i.COMPLETED_DATE?.ToString("yyyy-MM-dd");
                    };
                    return defect;
                }

            }
        }
        #endregion

        #region Search Defects By Screen Name
        [HttpGet]
        [Route("api/Defects/SearchDefectsByScreen")]
        public IEnumerable<DEFECT> SearchDefectsByDate(String screenName)
        {

            using (DefectsDBEntities entities = new DefectsDBEntities())
            {
                if (screenName != null)
                {
                    IEnumerable<DEFECT> defect = entities.DEFECTS.Where(a => a.SCREEN == screenName).ToList();
                    foreach (var i in defect)
                    {
                        //i.DEDUCTED_DATE = DateTime.ParseExact(i.DEDUCTED_DATE.ToString("MM/dd/yyyy", DateTimeFormatInfo.InvariantInfo), "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        i.DEDUCTED_DATE2 = i.DEDUCTED_DATE.ToString("yyyy-MM-dd");
                        i.COMPLETED_DATE2 = i.COMPLETED_DATE?.ToString("yyyy-MM-dd");
                    };
                    return defect;
                }
                else
                {
                    IEnumerable<DEFECT> defect = entities.DEFECTS.ToList();
                    foreach (var i in defect)
                    {
                        //i.DEDUCTED_DATE = DateTime.ParseExact(i.DEDUCTED_DATE.ToString("MM/dd/yyyy", DateTimeFormatInfo.InvariantInfo), "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        i.DEDUCTED_DATE2 = i.DEDUCTED_DATE.ToString("yyyy-MM-dd");
                        i.COMPLETED_DATE2 = i.COMPLETED_DATE?.ToString("yyyy-MM-dd");
                    };
                    return defect;
                }

            }
        }
        #endregion

        #region Add Defects
        [HttpPost]
        [Route("api/Defects/AddDefects")]
        public string AddDefects([FromBody]DEFECT defect)
        {
            using(DefectsDBEntities entities = new DefectsDBEntities())
            {
                //entities.DEFECTS.Add(defect);
                //entities.SaveChanges();
                if (defect != null && defect.DEFECT_NAME != null && defect.DESCRIPTION != null && defect.CREATED_BY_USER != null && defect.DEDUCTED_DATE != null && defect.PRIORITY != null && defect.ASSIGNED_TO_NAME != null && defect.ASSIGNED_TO_NAME != null && defect.STATUS != null)
                {
                    entities.DEFECTS.Add(new DEFECT()
                    {
                        DEFECT_NAME = defect.DEFECT_NAME,
                        DESCRIPTION = defect.DESCRIPTION,
                        CREATED_BY_USER = defect.CREATED_BY_USER,
                        DEDUCTED_DATE = defect.DEDUCTED_DATE,
                        PRIORITY = defect.PRIORITY,
                        SCREEN = defect.SCREEN,
                        ASSIGNED_TO_NAME = defect.ASSIGNED_TO_NAME,
                        ASSIGNED_TO_ID = defect.ASSIGNED_TO_ID,
                        COMPLETED_DATE = defect.COMPLETED_DATE,
                        STATUS = defect.STATUS,
                        COMMENTS = defect.COMMENTS,
                    });
                    entities.SaveChanges();
                    return "Added Successfully";
                }
                else
                {
                    return "Please fill the required details";
                }

            }

        }
        #endregion

        #region Update Defects

        [HttpPost]
        [Route("api/Defects/UpdateDefects")]
        public string UpdateDefects([FromBody]DEFECT defect)
        {
            using (DefectsDBEntities entities = new DefectsDBEntities())
            {
                //entities.DEFECTS.Add(defect);
                //entities.SaveChanges();
                if (defect != null && defect.DEFECT_NAME != null && defect.DESCRIPTION != null && defect.CREATED_BY_USER != null && defect.DEDUCTED_DATE != null && defect.PRIORITY != null && defect.ASSIGNED_TO_NAME != null && defect.ASSIGNED_TO_NAME != null && defect.STATUS != null)
                {

                    IEnumerable<DEFECT> def = entities.DEFECTS.Where(a => a.DEFECT_ID == defect.DEFECT_ID).ToList();
                    if (def != null)
                    {
                        foreach (var item in def)
                        {
                            item.DEFECT_NAME = defect.DEFECT_NAME;
                            item.DESCRIPTION = defect.DESCRIPTION;
                            item.CREATED_BY_USER = defect.CREATED_BY_USER;
                            item.DEDUCTED_DATE = defect.DEDUCTED_DATE;
                            item.PRIORITY = defect.PRIORITY;
                            item.SCREEN = defect.SCREEN;
                            item.ASSIGNED_TO_NAME = defect.ASSIGNED_TO_NAME;
                            item.ASSIGNED_TO_ID = defect.ASSIGNED_TO_ID;
                            item.COMPLETED_DATE = defect.COMPLETED_DATE;
                            item.STATUS = defect.STATUS;
                            item.COMMENTS = defect.COMMENTS;
                        }
                        entities.SaveChanges();
                        return "Added Successfully";
                    }
                    else
                    {
                        return "No defects Found";
                    }
                }
                else
                {
                    return "Please fill the required details";
                }

            }
        }

        #endregion

        #region Delete Defects


        [HttpPost]
        [Route("api/Defects/DeleteDefects")]
        public string DeleteDefects(Defect_Ids id)
        {
            DefectsDBEntities entities = new DefectsDBEntities();
            if (id != null)
            {
                foreach (var item in id.DEFECT_IDS)
                {
                    DEFECT defect = entities.DEFECTS.FirstOrDefault(a => a.DEFECT_ID == item);
                    entities.DEFECTS.Remove(defect);
                }
                entities.SaveChanges();
                return "Deleted Successfully";
            }
            else
            {
                return "Please select the items to be deleted";
            }
        }
        #endregion

        #region Export Excel
        [HttpPost]
        [Route("api/Defects/ExportExcel")]
        public string ExportExcel(DefectsRequestEntity request)
        {
            DataTable dataTable = new DataTable();
            IEnumerable<DEFECT> details = GetDefectsForExcel(request);

            dataTable.Columns.Add("Defect ID");
            dataTable.Columns.Add("Defect Name/Change Name");
            dataTable.Columns.Add("Description");
            dataTable.Columns.Add("Created By");
            dataTable.Columns.Add("Deducted Date");
            dataTable.Columns.Add("Priority");
            dataTable.Columns.Add("Screen");
            dataTable.Columns.Add("Assigned To");
            dataTable.Columns.Add("Completed Date");
            dataTable.Columns.Add("Status");
            dataTable.Columns.Add("Comments");


            foreach (var item in details)
            {
                dataTable.Rows.Add(item.DEFECT_ID, item.DEFECT_NAME, item.DESCRIPTION, item.CREATED_BY_USER, item.DEDUCTED_DATE2, item.PRIORITY, item.SCREEN, item.ASSIGNED_TO_NAME, item.COMPLETED_DATE2, item.STATUS, item.COMMENTS);
            }
            string filePath = "C:/Users/U278411.OSKGLOBAL/Downloads";

            string folderPath = Path.Combine(filePath, "ExportExcel");
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            filePath = Path.Combine(folderPath, "Defects" + ".xlsx");
            if (File.Exists(filePath))
                File.Delete(filePath);

            
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dataTable, "Defects");
                wb.SaveAs(filePath);
            }

            return "Downloaded in " + filePath;
        }
        #endregion

        #region Get Defects For Export Excel


        [HttpPost]
        [Route("api/Defects/GetDefectsForExcel")]
        public IEnumerable<DEFECT> GetDefectsForExcel(DefectsRequestEntity request)
        {
            IEnumerable<DEFECT> defect = null;
            using (DefectsDBEntities entities = new DefectsDBEntities())
            {
                if (request.START_DATE!=null && request.END_DATE != null && request.SCREEN_NAME != null)
                {
                    if (request.START_DATE != null && request.END_DATE != null && request.SCREEN_NAME == null)
                    {
                        defect = entities.DEFECTS.Where(a => a.DEDUCTED_DATE >= request.START_DATE && a.DEDUCTED_DATE <= request.END_DATE).ToList();
                        foreach (var i in defect)
                        {
                            i.DEDUCTED_DATE2 = i.DEDUCTED_DATE.ToString("dd/MM/yyyy");
                            i.COMPLETED_DATE2 = i.COMPLETED_DATE?.ToString("dd/MM/yyyy");
                        };
                    }
                    if (request.SCREEN_NAME != null && request.START_DATE == null && request.END_DATE == null)
                    {
                        defect = entities.DEFECTS.Where(a => a.SCREEN == request.SCREEN_NAME).ToList();
                        foreach (var i in defect)
                        {
                            i.DEDUCTED_DATE2 = i.DEDUCTED_DATE.ToString("dd/MM/yyyy");
                            i.COMPLETED_DATE2 = i.COMPLETED_DATE?.ToString("dd/MM/yyyy");
                        };
                    }
                    if (request.START_DATE != null && request.END_DATE != null && request.SCREEN_NAME != null)
                    {
                        defect = entities.DEFECTS.Where(a => a.DEDUCTED_DATE >= request.START_DATE && a.DEDUCTED_DATE <= request.END_DATE && a.SCREEN==request.SCREEN_NAME).ToList();
                        foreach (var i in defect)
                        {
                            i.DEDUCTED_DATE2 = i.DEDUCTED_DATE.ToString("dd/MM/yyyy");
                            i.COMPLETED_DATE2 = i.COMPLETED_DATE?.ToString("dd/MM/yyyy");
                        };
                    }
                }
                else
                {
                    defect = entities.DEFECTS.ToList();
                    foreach (var i in defect)
                    {
                        //i.DEDUCTED_DATE = DateTime.ParseExact(i.DEDUCTED_DATE.ToString("MM/dd/yyyy", DateTimeFormatInfo.InvariantInfo), "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        i.DEDUCTED_DATE2 = i.DEDUCTED_DATE.ToString("dd/MM/yyyy");
                        i.COMPLETED_DATE2 = i.COMPLETED_DATE?.ToString("dd/MM/yyyy");
                    };
                }
                return defect;
            }
            
        }
        #endregion
    }

    public class Defect_Ids
    {
        public IList<int> DEFECT_IDS { get; set; }
    }

    public class DefectsRequestEntity
    {
        public int? DEFECT_ID { get; set; } 
        public DateTime? START_DATE { get; set; }
        public DateTime? END_DATE { get; set; }
        public string SCREEN_NAME { get; set; }
    }
}
